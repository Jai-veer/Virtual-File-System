* There are some limitation to be taken in mind when executing my program.
* As I throughly tested there is no sign of segmentation fault.
* Always user should not mention path with end of /. 
* In some Cases I have handled but in most cases in may lead to some bug.
* Handling space is done.
* User is allowed to give relative or absolute path for cat, mkdir, rmdir ls -R and so on commands.
* cd .. should be given as "cd .." it should not be mentioned more.
* In ls -R user should give the directory. I will not take current working directory.
* More or less I tried to make the same appearance of terminal but it may not true always.

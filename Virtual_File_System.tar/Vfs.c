/*
 * =====================================================================================
 *
 *       Filename:  Vfs.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  Tuesday 19 December 2017 03:38:19  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Jaiveer (), sp.Jaiveer@gmail.com
 *   Organization:  Think Work Corporation
 *
 * =====================================================================================
 */

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>


char *PWD,*Temp_PWD; //To point the currect working directory string in the memory.
char ParseName[256]; //This array is for a function called PathParser.
int All_Flag=0; //This variable is for a functions related to ls.
int errno=0;
int CD_Flag=0;

struct Directory { //The directory structure
	struct Directory *DPtr; //To point the Directory which would probably stored inside the directory. To point sub directory.
	struct File *FPtr; //to point to files that are present inside the directory.
	struct Directory *Next; //To point to the neighbour directory which is having same parent directory.
	struct Directory *Parent;
	char *Name; //To store the name of the directory.
}*home;

struct File { //The file structure
	struct File *Next; //To point neighbour file which is having same parent directory
	char *Name; //To store the name of the file.
	char *Content; //To store the content of the file.
};

struct History { //History structure
	char *Command; //To store the command
	struct History *Next; //To point the before command.
}*top,*tail,*hist_temp;

int GetString(char *); //To get any string without any error.
void ShrinkSpace(char []); //To shrink the space.
int CommandFinder(char *); //To find which command did the user gave.
void AddtoHistory(char *); //To add a command to history.
void PrintHistory(void); //To print the history
void Descend(char *); //To go back to parent directory.
void Mkdir(char *); //To make directory to create it.
struct Directory *FindDir(char *); //To find the directory using a path.
struct Directory *GoIntoDir(char *,struct Directory *); //To go into a directory which is in the given parent directory.
int CountDirectory(char *); //to count how many directories 
char *PathParser(char *, int ); //To parse the given path and give us num string with / as the delimiter.
char *CorrectPath(char *); //To correct the path whether if it is given relative path it will be converted to absolute path.
struct File *FindFile(char *,struct Directory *); //To find a file which is in the given parent directory.
struct File *Cat_Create(char *); //To create a new file.
void Main_Cat_Overwrite(char *); //To Overwrite or to create if to create it will call back to create file else erase the content and change it.
void Change_Directory(char *); //To change the current working directory.
void Cat_Concat(struct File *); //To append a file.
void Main_Cat_Append(char *); //To create if the file isn't there else if there it will append.
void Cat_FileName(char *); //To display the contents in the file 
void Normal_List(char *); //To list the current working directory.
void RM_Regular(char *); //To remove files.
void RMDIR_Regular(char *); //to remove directories.
struct Directory *FindDirectory(char *,struct Directory *); //To go into a directory which is in the given parent directory.
void Mkdir_Option(char *); //To create a directory if not there.
int Mkdir_Restrictor(char *); //To not create directory which as name which is already present.
void Recursive_List(struct Directory *,char *); //To list recursive ls -r option.
char *Path_Validator(char *); //To validate the path given 
int Cat_Restrictor(char *);
int nstrcmp(char *,char *,int); //To compare with numbers.
void RMDIR_R(char *); //To remove a directories recursively

void main() {
	if(home==NULL) { //To create home directory in initial
		home=(struct Directory *) malloc(sizeof(struct Directory));
		home->DPtr=NULL;
		home->FPtr=NULL;
		home->Next=NULL;
		home->Parent=home;
		home->Name=(char *) malloc(strlen("home")*sizeof(char));
		strcpy(home->Name,"home");
		PWD=(char *) malloc(strlen("/home"));
		strcpy(PWD,"/home");
	}
	char Command[100000],Buffer[100000],*Path,*Tmp_Path,*PathPtr;
	struct Directory *Temprovary_Dir;
	while(1) {
		printf("%s$ ",PWD);
		if(GetString(Command)) {
			ShrinkSpace(Command);
			switch(CommandFinder(Command)) { 
				case 1: //Cat append operation
					if(strlen((PathParser(&Command[7],CountDirectory(&Command[7]))))>256) {
						printf("bash: %s: File name too long\n",PathParser(&Command[6],CountDirectory(&Command[7])));
						break;
					}
					Path=(char *) malloc((strlen(&Command[6]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[7]));
					Main_Cat_Append(Path);
					break;
				case 2:  //Cat create operation
					if(strlen((PathParser(&Command[6],CountDirectory(&Command[6]))))>256) {
						printf("bash: %s: File name too long\n",PathParser(&Command[6],CountDirectory(&Command[7])));
						break;
					}
					Path=(char *) malloc((strlen(&Command[5]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[6]));
					Main_Cat_Overwrite(Path);
					break;
				case 3: //cat filename operation.
					if(strlen((PathParser(&Command[4],CountDirectory(&Command[4]))))>256) {
						printf("bash: %s: File name too long\n",PathParser(&Command[6],CountDirectory(&Command[7])));
						break;
					}
					Path=(char *) malloc((strlen(&Command[3]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[4]));
					Cat_FileName(Path);
					break;
				case 4: //To list like ls -a 
					All_Flag=1;
					Normal_List(PWD);
					All_Flag=0;
					break;
				case 5: //To list recursively.
					Path=(char *) malloc(((strlen(&Command[5]))+5)*sizeof(char));
					strcpy(Path,&Command[6]);
					Path=CorrectPath(Path);
					Tmp_Path=(char *) malloc(strlen(Path)+5);
					strcat(Tmp_Path,Path);
					strcat(Tmp_Path,"/");
					Recursive_List(FindDirectory(PathParser(Path,CountDirectory(Path)),FindDir(Path)),(Tmp_Path));
					break;
				case 6: //To list the current directory.
					Normal_List(PWD);
					break;
				case 7: //To create directory mkdir -p command.
					Path=(char *) malloc((strlen(&Command[8]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[9]));
					if((strlen(Path))!=0)
					Mkdir_Option(Path);
					break;
				case 8: //To create directory.
					if(strlen((PathParser(&Command[6],CountDirectory(&Command[6]))))>256) {
						printf("bash: %s: File name too long\n",PathParser(&Command[6],CountDirectory(&Command[7])));
						break;
					}
					Path=(char *) malloc((strlen(&Command[5]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[6]));
					if((strlen(Path))!=0)
					Mkdir(Path);
					break;
				case 9: //To remove directory
					Path=(char *) malloc((strlen(&Command[4]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[6]));
					RMDIR_Regular(Path);
					break;
				case 10: //To remove directory recursively.
					Path=(char *) malloc((strlen(&Command[5]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[6]));
					RMDIR_R(Path);
					break;
				case 11: //To remove file 
					Path=(char *) malloc((strlen(&Command[2]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[3]));
					RM_Regular(Path); 
					break;
				case 12: //To go back to the home directory.
					PWD=realloc(PWD,6);
					strcpy(PWD,"/home");
					break;
				case 13: //To go back to the home directory.
					PWD=realloc(PWD,6);
					strcpy(PWD,"/home");
					break;
				case 14: //To use the history command.
					PrintHistory();
					break;
				case 15: //To use clear command.
					system("clear");
					break;
				case 16: //To use Pwd command.
					printf("%s\n",PWD);
					break;
				case 17: //To change the directory.
					Path=(char *) malloc((strlen(&Command[2]))*sizeof(char));
					strcpy(Path,Path_Validator(&Command[3]));
					Change_Directory(Path);
					break;
				case 18: //To use cat command.
					while((fgets(Buffer,10000,stdin))!=NULL)
						fputs(Buffer,stdout);
					break;
				default :
					printf("%s : command not found\n",Command);
			}
			ShrinkSpace(Command);
			if(errno==0) {
				AddtoHistory(Command);
			} else if(errno==1) {
				errno=0;
			}
		}
	}
}

void AddtoHistory(char *Command) { //To add a command to history.
	struct History *NewNode;
	NewNode=(struct History *) malloc(sizeof(struct History));
	NewNode->Command=(char *) malloc((strlen(Command)));
	strcpy(NewNode->Command,Command);
	if(top==NULL) {
		top=NewNode;
		tail=NewNode;
		top->Next=NULL;
	} else {
		tail->Next=NewNode;
		tail=NewNode;
		tail->Next=NULL;
	}
}

void PrintHistory(void) { //To print the history.
	int Count;
	for(Count=1,hist_temp=top;hist_temp->Next!=NULL;hist_temp=hist_temp->Next,Count++)
		printf("%d\t%s\n",Count,hist_temp->Command);
	printf("%d\t%s\n",Count,hist_temp->Command);
}

int GetString(char *Ptr) {  //To get a string.
	int Count;
	char *Dup_Ptr=Ptr;
	for(Count=0;(*Ptr=getchar())!='\n';Ptr++,Count++) 
		;
	*Ptr='\0';
	if(Count==0) {
		return 0;	
	} else {
		return 1;
	}
}

int CommandFinder(char *Command) { //To find which command given
	if((nstrcmp(Command,"cat >>",5)==0))
		return 1;
	else if((nstrcmp(Command,"cat >",4)==0))
		return 2;
	else if((nstrcmp(Command,"cat ",3)==0))
		return 3;
	else if((nstrcmp(Command,"ls -a",4)==0))
		return 4;
	else if((nstrcmp(Command,"ls -R",4)==0))
		return 5;
	else if((strcmp(Command,"ls")==0))
		return 6;
	else if((nstrcmp(Command,"mkdir -p",7)==0))
		return 7;
	else if((nstrcmp(Command,"mkdir",4)==0))
		return 8;
	else if((nstrcmp(Command,"rmdir",4)==0))
		return 9;
	else if((nstrcmp(Command,"rm -r",4)==0))
		return 10;
	else if((nstrcmp(Command,"rm",1)==0))
		return 11;
	else if((strcmp(Command,"cd ~")==0))
		return 12;
	else if((strcmp(Command,"cd")==0))
		return 13;
	else if((strcmp(Command,"history")==0))
		return 14;
	else if((strcmp(Command,"clear")==0))
		return 15;
	else if((strcmp(Command,"pwd")==0))
		return 16;
	else if((nstrcmp(Command,"cd ",2)==0))
		return 17;
	else if((strcmp(Command,"cat")==0))
		return 18;
	else 
		return 0;
}

void Descend(char *Path) { //To descend to parent directory.
	char *Tmp_Path=Path;
	if((strlen(Path))>5) {
		Tmp_Path+=strlen(Path);
		for( ;*Tmp_Path!='/';Tmp_Path--)
			*Tmp_Path='\0';
		*Tmp_Path='\0';
	}
}

void Mkdir(char *Path) { //To create a directory.
	struct Directory *Temprovary;
	Path=CorrectPath(Path);
	if((Mkdir_Restrictor(Path))!=0) {
		if((Temprovary=FindDir(Path))!=NULL) {
			struct Directory *NewDirectory=(struct Directory *) malloc(sizeof(struct Directory));
			NewDirectory->Name=(char *) malloc(strlen(PathParser(Path,CountDirectory(Path))));
			strcpy(NewDirectory->Name,ParseName);
			NewDirectory->DPtr=NULL;
			NewDirectory->FPtr=NULL;
			NewDirectory->Next=Temprovary->DPtr;
			Temprovary->DPtr=NewDirectory;
			NewDirectory->Parent=Temprovary;
		} else {
			printf("mkdir: %s: No such file or directory\n",Path);	
		}
	} else {
		printf("mkdir: cannot create directory ‘%s’: File exists\n",Path);
	}
}

struct Directory *FindDir(char *Path) { //Used to go to a certain directory using a path.
	struct Directory *Temprovary=home;
	int TotalDir=CountDirectory(Path),CountDir=2;
	char *DupPath=(char *) malloc(sizeof(PWD)+20);
	strcpy(DupPath,"/home");
	for( ;CountDir<TotalDir && (Temprovary=GoIntoDir(PathParser(Path,CountDir),Temprovary))!=NULL; CountDir++) {
		if(CD_Flag==1) {
			if((strcmp(PathParser(Path,CountDir),".."))==0) {
				if((strcmp(DupPath,"/home"))!=0) {	
					Descend(DupPath);
				}
			} else {
				strcat(DupPath,"/");
				strcat(DupPath,PathParser(Path,CountDir));	
			}
		} else {
			;
		}
	}
	if(CountDir==TotalDir) {
		if(CD_Flag==1) {
			Temp_PWD=realloc(Temp_PWD,strlen(DupPath)+100);
			strcpy(Temp_PWD,DupPath);
			CD_Flag=0;
		}
		return Temprovary;
	} else {
		return NULL;
	}
}

struct Directory *GoIntoDir(char *Directory,struct Directory *HomeDir) { //To go into a directory which is present in the gven parent directory.
	struct Directory *Temprovary=HomeDir->DPtr;
	for( ;(strcmp(Directory,".."))==0 || Temprovary!=NULL && strcmp(Temprovary->Name,Directory)!=0 ; Temprovary=Temprovary->Next)
		if((strcmp(Directory,".."))==0) {
			Temprovary=HomeDir->Parent;	
			break;
		}
	if(Temprovary!=NULL && (strcmp(Temprovary->Name,Directory))==0) {
		return Temprovary;
	} else {
		if((strcmp(Directory,".."))==0 && Temprovary!=NULL) {
			return Temprovary;
		} else {
			return NULL;
		}
	}
}

int CountDirectory(char *Path) { //To count how many directories given in the path.
	int Count;
	for(Count=0;*Path=='/' || *Path!='\0';Path++)
		if(*Path=='/')
			Count++;
	return Count;
}

char *PathParser(char *Path, int Deep) { //To parse a path and get the name in the deep.
	int Count_Deep;
	char *PathPtr;
	ParseName[0]='\0';
	for(Count_Deep=1;Count_Deep<=Deep;Count_Deep++,Path++)
		for( ;*Path!='/' && *Path!='\0';Path++)
			;
	for(PathPtr=ParseName;(*PathPtr=*Path)!='/' && *PathPtr!='\0';PathPtr++, Path++)
		;
	*PathPtr='\0';
	if((strcmp(ParseName,"/"))==0) {
		ParseName[0]='\0';
	}
	return ParseName;
}

char *CorrectPath(char *Path) { //To correct the path if the user has gave the absolute path.
	int Sum=0;
	char *Temp,*DupTemp;
	if((strlen(Path))>4 &&(strncmp(Path,"/home",5))==0) {
		return Path;
	} else {
		Sum=(strlen(Path)+strlen(PWD)+5);
		Path=realloc(Path,Sum);
		Temp=(char *) malloc(Sum);
		strcpy(Temp,Path);
		strcpy(Path,PWD);
		if(*Temp=='/')
			;
		else 
			strcat(Path,"/");
		strcat(Path,Temp);
		if(*(Path+(strlen(Path))-1)=='/')
			*(Path+(strlen(Path))-1)='\0';
	}
	for(Temp=Path;*Temp!='\0';Temp++) {
		if(*Temp=='/' && *(Temp+1)=='/') {
Remove :
			for(DupTemp=Temp;*DupTemp!='\0';DupTemp++)
				*DupTemp=*(DupTemp+1);
			if(*(Temp+1)!='\0' && *(Temp+1)=='/') {
				goto Remove;		
			} 
		}
	}

	return Path;
}

struct File *FindFile(char *FileName,struct Directory *Temprovary_Dir) { //To find a file in the given parent directory.
	struct File *Temprovary_File;
	if(Temprovary_Dir!=NULL)
		Temprovary_File=Temprovary_Dir->FPtr;
	else
		Temprovary_File=NULL;
	for( ;Temprovary_File!=NULL && (strcmp(Temprovary_File->Name,FileName))!=0;Temprovary_File=Temprovary_File->Next)
		;
	if(Temprovary_File!=NULL && (strcmp(Temprovary_File->Name,FileName))==0) 
		return Temprovary_File;
	else
		return NULL;
}

struct Directory *FindDirectory(char *Directory_Name,struct Directory *Temprovary_Dir) { //To find a directory in the given parent directory.
	if(Temprovary_Dir!=NULL)
		Temprovary_Dir=Temprovary_Dir->DPtr;
	for( ;Temprovary_Dir!=NULL && (strcmp(Temprovary_Dir->Name,Directory_Name))!=0;Temprovary_Dir=Temprovary_Dir->Next)
		;
	if(Temprovary_Dir!=NULL && (strcmp(Temprovary_Dir->Name,Directory_Name))==0)
		return Temprovary_Dir;
	else
		return NULL;
}

struct File *Cat_Create(char *FileName) { //To Create a file
	struct File *NewFile;
	int Counter1=1,Counter2=1;
	char *Character,Temp[25];
	Character=Temp;
	NewFile=(struct File *) malloc(sizeof(struct File));
	NewFile->Name=(char *) malloc((sizeof(char)*strlen(FileName)));
	strcpy(NewFile->Name,FileName);
	NewFile->Next=NULL;
	NewFile->Content=(char *) malloc(sizeof(char)*20);
	while(1) {
		for(Counter2=1,Character=Temp;Counter2<20 && (*Character=getchar())!=EOF;Counter2++,Counter1++,Character++)
			;
		if(*Character==EOF) {
			*Character='\0';
			NewFile->Content=realloc(NewFile->Content,Counter1);
			strcat(NewFile->Content,Temp);
			break;
		}
		*Character='\0';
		NewFile->Content=realloc(NewFile->Content,Counter1);
		strcat(NewFile->Content,Temp);
	}
	return NewFile;
}

void Main_Cat_Overwrite(char *Path) { //main file which will decide whether it should create a new file or to replace the content.
	Path=CorrectPath(Path);
	struct Directory *Temprovary_Dir;
	struct File *Temprovary_File;
	if((Temprovary_Dir=FindDir(Path))!=NULL) { 
		if(Cat_Restrictor(Path)) {
			if((Temprovary_File=FindFile(PathParser(Path,CountDirectory(Path)),Temprovary_Dir))!=NULL) {
				Temprovary_File->Content=realloc(Temprovary_File->Content,20);
				*(Temprovary_File->Content)='\0';
				int Counter1=1,Counter2=1;
				char *Character,Temp[25];
				Character=Temp;
				while(1) {
					for(Counter2=1,Character=Temp;Counter2<20 && (*Character=getchar())!=EOF;Counter2++,Counter1++,Character++)
						;
					if(*Character==EOF) {
						*Character='\0';
						Temprovary_File->Content=realloc(Temprovary_File->Content,Counter1);
						strcat(Temprovary_File->Content,Temp);
						break;
					}
					*Character='\0';
					Temprovary_File->Content=realloc(Temprovary_File->Content,Counter1);
					strcat(Temprovary_File->Content,Temp);
				}
			} else {
				Temprovary_File=Cat_Create(PathParser(Path,CountDirectory(Path)));	
				Temprovary_File->Next=Temprovary_Dir->FPtr;
				Temprovary_Dir->FPtr=Temprovary_File;
			}
		} else {
			printf("cat: cannot create file ‘%s’: File exists\n",Path);
		}
	} else {
		printf("cat: %s: No such file or directory\n",Path);
	}
}

void Change_Directory(char *Path) { //To change the directory if the path is given.
	CD_Flag=1;
	Path=CorrectPath(Path);
	Path=realloc(Path,strlen(Path)+5);
	if((strcmp(Path,"/home/"))==0)
		strcat(Path,"a");
	else
		strcat(Path,"/a");
	struct Directory *Temprovary;
	if((Temprovary=FindDir(Path))!=NULL) {
		Path=realloc(Path,strlen(Path)-5);
		*(Path+(strlen(Path)-2))='\0';
		PWD=realloc(PWD,strlen(Temp_PWD)+100);
		strcpy(PWD,Temp_PWD);
	} else {
		*(Path+(strlen(Path)-1))='\0';
		printf("cd: %s: No such file or directory\n",Path);
	}
	CD_Flag=0;
}

void Main_Cat_Append(char *Path) { //To create if the file is not given else append the file.
	Path=CorrectPath(Path);
	struct Directory *Temprovary_Dir;
	struct File *Temprovary_File;
	if((Temprovary_Dir=FindDir(Path))!=NULL) {
		if((Temprovary_File=FindFile((PathParser(Path,(CountDirectory(Path)))),Temprovary_Dir))!=NULL) {
			Cat_Concat(Temprovary_File);
		} else {
			Main_Cat_Overwrite(Path);
		}
	} else {
		printf("cat: %s: No such file or directory\n",Path);
	}
}
void Cat_Concat(struct File *Old_File) { //To concat a file.
	int Counter1=strlen(Old_File->Content),Counter2=1;
	char *Character,Temp[25];
	Old_File->Content=realloc(Old_File->Content,Counter1+20);
	while(1) {
		for(Counter2=1,Character=Temp;Counter2<20 && (*Character=getchar())!=EOF;Counter2++,Counter1++,Character++)
			;
		if(*Character==EOF) {
			*Character='\0';
			Old_File->Content=realloc(Old_File->Content,Counter1);
			strcat(Old_File->Content,Temp);
			break;
		}
		*Character='\0';
		Old_File->Content=realloc(Old_File->Content,Counter1);
		strcat(Old_File->Content,Temp);
	}
}

void Cat_FileName(char *Path) { //To print the file.
	Path=CorrectPath(Path);
	struct Directory *Temprovary_Dir;
	struct File *Temprovary_File;
	if((Temprovary_Dir=FindDir(Path))!=NULL) {
		if((Temprovary_File=FindFile((PathParser(Path,(CountDirectory(Path)))),Temprovary_Dir))!=NULL) {
			printf("%s\n",Temprovary_File->Content);
		} else {
			printf("cat: %s: No such file or directory\n",Path);
		}
	} else {
		printf("cat: %s: No such file or directory\n",Path);
	}
}

void RM_Regular(char *Path) { //To remove file.
	Path=CorrectPath(Path);
	struct Directory *Temprovary_Dir;
	struct File *Temprovary_File;
	if((Temprovary_Dir=FindDir(Path))!=NULL) {
		if((FindFile((PathParser(Path,(CountDirectory(Path)))),Temprovary_Dir))!=NULL) {
			if(Temprovary_Dir->FPtr!=NULL && (strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_Dir->FPtr)->Name))!=0) {
				for(Temprovary_File=Temprovary_Dir->FPtr;Temprovary_File->Next!=NULL && (strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_File->Next)->Name))!=0; ) 
					Temprovary_File=Temprovary_File->Next;
				if((strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_File->Next)->Name))==0) {
					Temprovary_File->Next=(Temprovary_File->Next)->Next;
				}
			} else {
				Temprovary_Dir->FPtr=(Temprovary_Dir->FPtr)->Next;	
			}
		} else {
			printf("rm: %s: No such file or directory\n",Path);
		}
	} else {
		printf("rm: %s: No such file or directory\n",Path);
	}
}

void RMDIR_Regular(char *Path) { //To remove a directory.
	Path=CorrectPath(Path);
	struct Directory *Temprovary_Dir;
	if((Temprovary_Dir=FindDirectory((PathParser(Path,(CountDirectory(Path)))),FindDir(Path)))!=NULL) {
		Temprovary_Dir=FindDir(Path);	
		if(Temprovary_Dir->DPtr!=NULL && (strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_Dir->DPtr)->Name))!=0) { 
			for(Temprovary_Dir=Temprovary_Dir->DPtr;Temprovary_Dir->Next!=NULL && (strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_Dir->Next)->Name))!=0; ) 
				Temprovary_Dir=Temprovary_Dir->Next;
			if((strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_Dir->Next)->Name))==0) {
				if((Temprovary_Dir->Next)->DPtr==NULL && (Temprovary_Dir->Next)->FPtr==NULL)
					Temprovary_Dir->Next=(Temprovary_Dir->Next)->Next;
				else
					printf("rmdir: failed to remove ‘%s’: Directory not empty\n",(Temprovary_Dir->Next)->Name);
			}
		} else {
			if((Temprovary_Dir->DPtr)->FPtr==NULL && (Temprovary_Dir->DPtr)->DPtr==NULL)
				Temprovary_Dir->DPtr=(Temprovary_Dir->DPtr)->Next;
			else 
				printf("rmdir: failed to remove ‘%s’: Directory not empty\n",(Temprovary_Dir->DPtr)->Name);
		}
	} else {
		printf("rmdir: %s: No such file or directory\n",Path);
	}
}
void RMDIR_R(char *Path) { //To remove a directory.
	Path=CorrectPath(Path);
	struct Directory *Temprovary_Dir;
	if((Temprovary_Dir=FindDirectory((PathParser(Path,(CountDirectory(Path)))),FindDir(Path)))!=NULL) {
		Temprovary_Dir=FindDir(Path);	
		if(Temprovary_Dir->DPtr!=NULL && (strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_Dir->DPtr)->Name))!=0) { 
			for(Temprovary_Dir=Temprovary_Dir->DPtr;Temprovary_Dir->Next!=NULL && (strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_Dir->Next)->Name))!=0; ) 
				Temprovary_Dir=Temprovary_Dir->Next;
			if((strcmp((PathParser(Path,CountDirectory(Path))),(Temprovary_Dir->Next)->Name))==0) {
					Temprovary_Dir->Next=(Temprovary_Dir->Next)->Next;
			}
		} else {
				Temprovary_Dir->DPtr=(Temprovary_Dir->DPtr)->Next;
		}
	} else {
		printf("rmdir: %s: No such file or directory\n",Path);
	}
}
int Cat_Restrictor(char *Path)  { 
	if((strcmp(PathParser(Path,(CountDirectory(Path))),"."))==0 || (strcmp(PathParser(Path,(CountDirectory(Path))),".."))==0 || (strcmp(PathParser(Path,(CountDirectory(Path))),"/"))==0 ) {
		return 0;
	}
	if(FindDirectory((PathParser(Path,(CountDirectory(Path)))),FindDir(Path))!=NULL) {
		return 0;
	} else {
		return 1;
	}
}
int Mkdir_Restrictor(char *Path)  { 
	if((strcmp(PathParser(Path,(CountDirectory(Path))),"."))==0 || (strcmp(PathParser(Path,(CountDirectory(Path))),".."))==0 || (strcmp(PathParser(Path,(CountDirectory(Path))),"/"))==0 ) {
		return 0;
	}
	if(FindDirectory((PathParser(Path,(CountDirectory(Path)))),FindDir(Path))!=NULL || FindFile((PathParser(Path,(CountDirectory(Path)))),FindDir(Path))!=NULL) {
		return 0;
	} else {
		return 1;
	}
}

void Normal_List(char *Tmp_Path) { //To list the current directory.
	Tmp_Path=CorrectPath(Tmp_Path);
	char *Path=(char *) malloc(strlen(Tmp_Path)+4);
	strcpy(Path,Tmp_Path);
	strcat(Path,"/");
	struct Directory *Temprovary_Dir=FindDir(Path),*Temprovary_Sub_Dir;
	struct File *Temprovary_File;
	if(Temprovary_Dir!=NULL) {
		if(Temprovary_Dir->DPtr!=NULL) {
			for(Temprovary_Sub_Dir=Temprovary_Dir->DPtr;Temprovary_Sub_Dir->Next!=NULL;Temprovary_Sub_Dir=Temprovary_Sub_Dir->Next)
				if((strncmp(Temprovary_Sub_Dir->Name,".",1))!=0 || All_Flag==1)
					printf("%s/\t",Temprovary_Sub_Dir->Name);	
			if((strncmp(Temprovary_Sub_Dir->Name,".",1))!=0 || All_Flag==1)
				printf("%s/\t",Temprovary_Sub_Dir->Name);	
		}
		if(Temprovary_Dir->FPtr!=NULL) {
			for(Temprovary_File=Temprovary_Dir->FPtr;Temprovary_File->Next!=NULL;Temprovary_File=Temprovary_File->Next)
				if((strncmp(Temprovary_File->Name,".",1))!=0 || All_Flag==1)
					printf("%s\t",Temprovary_File->Name);
			if((strncmp(Temprovary_File->Name,".",1))!=0 || All_Flag==1)
				printf("%s\t",Temprovary_File->Name);
		}
	}
	if((FindDir(Path))!=NULL && (FindDir(Path))->DPtr!=NULL || (FindDir(Path))->FPtr!=NULL)
		printf("\n");
}


char *Path_Validator(char *Path) { //To validate the path.
	char *Tmp_Path=Path;
	for( ;*Tmp_Path!=' ' && *Tmp_Path!='\0';Tmp_Path++)
		;
	*Tmp_Path='\0';
	return Path;
}

void Mkdir_Option(char *Path) { //To use Mkdir -p option.
	Path=CorrectPath(Path);
	char *Tmp_Path=(char *) malloc(strlen(Path)+50);
	strcpy(Tmp_Path,"/home/");
	strcat(Tmp_Path,PathParser(Path,2));
	int Counter=2,Total=CountDirectory(Path);
	for( ;Counter<Total && FindDirectory((PathParser(Tmp_Path,Counter)),(FindDir(Tmp_Path)))!=NULL; Counter++) {
		Tmp_Path=realloc(Tmp_Path,(strlen(Tmp_Path)+strlen(PathParser(Path,Counter+1))+5));
		strcat(Tmp_Path,"/");
		strcat(Tmp_Path,PathParser(Path,Counter+1));
	}
	for( ;Counter<Total;Counter++) {
		Mkdir(Tmp_Path);
		Tmp_Path=realloc(Tmp_Path,(strlen(Tmp_Path)+strlen(PathParser(Path,Counter+1))+5));
		strcat(Tmp_Path,"/");
		strcat(Tmp_Path,PathParser(Path,Counter+1));
	}
	Mkdir(Tmp_Path);
}

int nstrcmp(char *Src1,char *Src2,int num) { //To compare two string till num characters.
	int count=0;
	for( ;count<=num && *Src1!='\0' && *Src2!='\0' && *Src1==*Src2;count++,Src1++,Src2++)
		;
	if(count>num)
		return 0;
	else
		return 1;
}

void ShrinkSpace(char text[]) { //To Shrink the space of input Command.
	char blank[100000];
	int c = 0, d = 0;
	while (text[c] != '\0') {
		if (text[c] == ' ') {
			int temp = c + 1;
			if (text[temp] != '\0') {
				while (text[temp] == ' ' && text[temp] != '\0') {
					if (text[temp] == ' ') {
						c++;
					}  
					temp++;
				}
			}
		}
		blank[d] = text[c];
		c++;
		d++;
	}
	blank[d] = '\0';
	if(blank[0]==' ')
		strcpy(text,&blank[1]);
	else 
		strcpy(text,blank);
	if(text[strlen(text)-1]==' ')
		text[strlen(text)-1]='\0';
}

void Recursive_List(struct Directory *Temprovary_Dir,char *Path) //To list Recursively
{
	char Next_Path[10000];
	struct File *Temprovary_File;
	if(Temprovary_Dir!=NULL)
		Temprovary_File=Temprovary_Dir->FPtr;
	if ( Temprovary_File != NULL )
	{ 
		printf("%s ",Temprovary_File->Name);
		while(Temprovary_File->Next != NULL )
		{
			Temprovary_File=Temprovary_File->Next;
			printf("%s ",Temprovary_File->Name);
		}
	}
	printf("\n");
	if( Temprovary_Dir!=NULL && Temprovary_Dir->DPtr != NULL )
	{
		Temprovary_Dir=Temprovary_Dir->DPtr;
		printf("%s%s:\n",Path,Temprovary_Dir->Name);
		sprintf(Next_Path,"%s%s/",Path,Temprovary_Dir->Name);
		Recursive_List(Temprovary_Dir,Next_Path);
		while( Temprovary_Dir->Next != NULL )
		{
			Temprovary_Dir=Temprovary_Dir->Next;
			printf("%s%s :\n",Path,Temprovary_Dir->Name);
			sprintf(Next_Path,"%s%s/",Path,Temprovary_Dir->Name);
			Recursive_List(Temprovary_Dir,Next_Path);
		}
	}
}

